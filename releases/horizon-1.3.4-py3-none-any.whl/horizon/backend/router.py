from typing import Annotated, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel
from .models import (
    VersionOut,
    UCTableConfig,
    ConnectionValidationResponse,
    BaselineMetrics,
    MonthlyConsumption,
    WorkspaceConsumption,
    UseCaseIn,
    UseCaseOut,
    PlannedConsumption
)
from .config import conf
from .consumption import (
    get_baseline_metrics,
    get_monthly_history,
    get_workspace_breakdown
)
from .usecases import (
    create_use_case,
    list_use_cases,
    get_use_case,
    update_use_case,
    delete_use_case,
    calculate_projected_consumption
)

api = APIRouter(prefix=conf.api_prefix)


# Simple UserOut model (replaces SDK version for demo)
class UserOut(BaseModel):
    id: str
    user_name: str
    display_name: Optional[str] = None
    active: bool = True


@api.get("/version", response_model=VersionOut, operation_id="version")
async def version():
    return VersionOut.from_metadata()


@api.get("/current-user", response_model=UserOut, operation_id="currentUser")
def me():
    # Return mock user - OAuth disabled for PAT-only consumption queries
    return UserOut(
        id="mock-user-id",
        user_name="demo@databricks.com",
        display_name="Demo User",
        active=True
    )


# ============================================================================
# CONSUMPTION ENDPOINTS (v1.1.0)
# ============================================================================

@api.post("/connection/validate", response_model=ConnectionValidationResponse, operation_id="validateConnection")
def validate_connection(
    table_config: UCTableConfig
):
    """
    Validate Unity Catalog table connection (DISABLED - returns success for demo)

    Connection will be validated when dashboard loads with authenticated session
    """
    # Return mock success - actual validation happens when dashboard queries with user's OAuth
    return ConnectionValidationResponse(
        success=True,
        message=f"Table path accepted: {table_config.full_path}. Validation will occur on dashboard load.",
        table_path=table_config.full_path
    )


@api.get("/consumption/baseline", response_model=BaselineMetrics, operation_id="getBaselineMetrics")
def baseline_metrics(
    table_path: str
):
    """
    Get baseline consumption metrics (KPIs)
    
    Returns current month, average, workspace count, and date range
    """
    return get_baseline_metrics(None, table_path)


@api.get("/consumption/history", response_model=List[MonthlyConsumption], operation_id="getMonthlyHistory")
def monthly_history(
    table_path: str,
    months: int = 12
):
    """
    Get monthly consumption history
    
    Args:
        table_path: Full UC table path (catalog.schema.table)
        months: Number of recent months to return (default 12)
    """
    return get_monthly_history(None, table_path, months)


@api.get("/consumption/workspaces", response_model=List[WorkspaceConsumption], operation_id="getWorkspaceBreakdown")
def workspace_breakdown(
    table_path: str
):
    """
    Get per-workspace consumption breakdown
    
    Returns consumption summary for each workspace
    """
    return get_workspace_breakdown(None, table_path)


# ============================================================================
# USE CASE PLANNING ENDPOINTS (v1.3.0)
# ============================================================================

@api.post("/usecases", response_model=UseCaseOut, operation_id="createUseCase", status_code=201)
def create_use_case_endpoint(
    use_case: UseCaseIn,
    x_user_email: Optional[str] = Header(None, description="Email of the user creating this use case")
):
    """
    Create a new use case for planning
    
    Args:
        use_case: Use case details including expected DBU consumption
        x_user_email: Optional header to associate use case with a user (v1.3)
    
    Returns:
        Created use case with generated ID
    """
    return create_use_case(use_case, user_email=x_user_email)


@api.get("/usecases", response_model=List[UseCaseOut], operation_id="listUseCases")
def list_use_cases_endpoint(
    user_email: Optional[str] = None,
    customer_name: Optional[str] = None
):
    """
    List use cases with optional filtering (v1.3)
    
    Args:
        user_email: Filter by user email
        customer_name: Filter by customer/account name
    
    Returns:
        List of use cases (filtered if params provided)
    """
    return list_use_cases(user_email=user_email, customer_name=customer_name)


@api.get("/usecases/{use_case_id}", response_model=UseCaseOut, operation_id="getUseCase")
def get_use_case_endpoint(use_case_id: str):
    """
    Get a specific use case by ID
    
    Args:
        use_case_id: Use case ID
    
    Returns:
        Use case details
    
    Raises:
        404: Use case not found
    """
    use_case = get_use_case(use_case_id)
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    return use_case


@api.put("/usecases/{use_case_id}", response_model=UseCaseOut, operation_id="updateUseCase")
def update_use_case_endpoint(use_case_id: str, use_case: UseCaseIn):
    """
    Update an existing use case
    
    Args:
        use_case_id: Use case ID
        use_case: Updated use case details
    
    Returns:
        Updated use case
    
    Raises:
        404: Use case not found
    """
    updated = update_use_case(use_case_id, use_case)
    if not updated:
        raise HTTPException(status_code=404, detail="Use case not found")
    return updated


@api.delete("/usecases/{use_case_id}", operation_id="deleteUseCase", status_code=204)
def delete_use_case_endpoint(use_case_id: str):
    """
    Delete a use case
    
    Args:
        use_case_id: Use case ID
    
    Raises:
        404: Use case not found
    """
    success = delete_use_case(use_case_id)
    if not success:
        raise HTTPException(status_code=404, detail="Use case not found")


@api.get("/consumption/projected", response_model=List[PlannedConsumption], operation_id="getProjectedConsumption")
def projected_consumption(
    baseline_avg: float,
    start_month: str,
    months: int = 12,
    user_email: Optional[str] = None,
    customer_name: Optional[str] = None,
    use_case_ids: Optional[str] = None
):
    """
    Get projected consumption including baseline + planned use cases (v1.3)
    
    Args:
        baseline_avg: Historical average monthly DBU
        start_month: Starting month for projection (YYYY-MM)
        months: Number of months to project (default 12)
        user_email: Filter use cases by user email (v1.3)
        customer_name: Filter use cases by customer name (v1.3)
        use_case_ids: Comma-separated list of use case IDs to include (v1.3)
    
    Returns:
        List of projected monthly consumption with per-use-case breakdown
    """
    # Parse use_case_ids if provided
    ids_list = None
    if use_case_ids:
        ids_list = [id.strip() for id in use_case_ids.split(",") if id.strip()]
    
    projections = calculate_projected_consumption(
        baseline_avg, 
        start_month, 
        months,
        user_email=user_email,
        customer_name=customer_name,
        use_case_ids=ids_list
    )
    return [PlannedConsumption(**p) for p in projections]
