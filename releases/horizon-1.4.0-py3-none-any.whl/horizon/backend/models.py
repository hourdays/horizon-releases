from pydantic import BaseModel, Field
from datetime import datetime
from typing import List, Optional
from .. import __version__


class VersionOut(BaseModel):
    version: str

    @classmethod
    def from_metadata(cls):
        return cls(version=__version__)


# ============================================================================
# CONSUMPTION DATA MODELS (v1.1.0)
# ============================================================================

class ConsumptionRecord(BaseModel):
    """Single row from Unity Catalog consumption table"""
    sfdc_account_name: str = Field(..., description="Customer account name")
    workspace_name: str = Field(..., description="Workspace identifier")
    sfdc_workspace_id: int = Field(..., description="Workspace ID")
    yearMonth: str = Field(..., description="Month in YYYY-MM format")
    dbuDollars: float = Field(..., description="DBU cost in USD")


class UCTableConfig(BaseModel):
    """Unity Catalog table configuration"""
    catalog: str = Field(..., description="UC catalog name")
    schema_: str = Field(..., alias="schema", description="UC schema name")
    table: str = Field(..., description="UC table name")
    
    @property
    def full_path(self) -> str:
        """Returns full table path: catalog.schema.table"""
        return f"{self.catalog}.{self.schema_}.{self.table}"


class ConnectionValidationResponse(BaseModel):
    """Response from UC connection validation"""
    success: bool
    message: str
    table_path: str
    row_count: Optional[int] = None
    date_range: Optional[dict] = None  # {min: "YYYY-MM", max: "YYYY-MM"}


class BaselineMetrics(BaseModel):
    """Baseline consumption metrics"""
    last_full_month_dbu: float = Field(..., description="Last complete month DBU spend")
    average_monthly_dbu: float = Field(..., description="Average monthly DBU (last 12 full months)")
    last_3_months_total: float = Field(..., description="Total DBU spend for last 3 full months")
    total_workspaces: int = Field(..., description="Number of unique workspaces")
    earliest_month: str = Field(..., description="Earliest month in data")
    latest_full_month: str = Field(..., description="Latest complete month in data")


class MonthlyConsumption(BaseModel):
    """Monthly aggregated consumption"""
    month: str = Field(..., description="Month in YYYY-MM format")
    total_dbu: float = Field(..., description="Total DBU spend for month")
    workspace_count: int = Field(..., description="Number of active workspaces")


class WorkspaceConsumption(BaseModel):
    """Per-workspace consumption summary"""
    workspace_name: str
    workspace_id: int
    total_dbu: float = Field(..., description="Total DBU across all months")
    average_monthly_dbu: float = Field(..., description="Average monthly DBU")
    months_active: int = Field(..., description="Number of months with data")


# ============================================================================
# USE CASE PLANNING MODELS (v1.3.0)
# ============================================================================

# ============================================================================
# ACCOUNT CONFIGURATION MODELS (v1.4.0)
# ============================================================================

class AccountConfigIn(BaseModel):
    """Input model for creating/updating an account configuration"""
    customer_name: str = Field(..., min_length=1, max_length=200, description="Customer/account name (e.g., Veolia)")
    table_path: str = Field(..., min_length=5, max_length=500, description="Unity Catalog table path (catalog.schema.table)")


class AccountConfigOut(BaseModel):
    """Output model for an account configuration"""
    id: str = Field(..., description="Unique config ID")
    customer_name: str = Field(..., description="Customer/account name")
    table_path: str = Field(..., description="Unity Catalog table path")
    created_by: Optional[str] = Field(None, description="Email of user who created this config")
    created_at: str = Field(..., description="ISO timestamp")
    updated_at: str = Field(..., description="ISO timestamp")


class AccountConfigSearch(BaseModel):
    """Search result for account autocomplete"""
    customer_name: str
    table_path: str
    last_used_by: Optional[str] = None


# ============================================================================
# USE CASE PLANNING MODELS (v1.3.0)
# ============================================================================

class UseCaseIn(BaseModel):
    """Input model for creating/updating a use case"""
    name: str = Field(..., min_length=1, max_length=100, description="Use case name")
    description: Optional[str] = Field(None, max_length=500, description="Use case description")
    live_date: str = Field(..., description="Go-live date in YYYY-MM format")
    onboarding_months: int = Field(6, gt=0, le=12, description="Onboarding period before live (default 6 months)")
    dbu_at_scale: float = Field(..., gt=0, description="Target monthly DBU at full production scale")
    onboarding_pattern: str = Field("s-curve", description="Consumption ramp pattern: linear, hill, exponential, s-curve, front-loaded")
    category: Optional[str] = Field("other", description="Category: ml, analytics, etl, other")
    # v1.3: Multi-user support
    customer_name: Optional[str] = Field(None, max_length=100, description="Customer/account name for filtering")


class UseCaseOut(BaseModel):
    """Output model for a use case"""
    id: str = Field(..., description="Unique use case ID")
    name: str
    description: Optional[str]
    live_date: str
    onboarding_months: int
    dbu_at_scale: float
    onboarding_pattern: str
    category: str
    status: str = Field(..., description="Status: onboarding, live, completed")
    created_at: str = Field(..., description="ISO timestamp")
    updated_at: str = Field(..., description="ISO timestamp")
    # v1.3: Multi-user support
    user_email: Optional[str] = Field(None, description="Email of user who created this use case")
    customer_name: Optional[str] = Field(None, description="Customer/account name")


class UseCaseConsumption(BaseModel):
    """Per-use-case consumption for a specific month (v1.3)"""
    use_case_id: str = Field(..., description="Use case ID")
    use_case_name: str = Field(..., description="Use case name")
    dbu: float = Field(..., description="DBU consumption for this use case in this month")
    percentage: float = Field(..., description="Percentage of target scale (0-100)")


class PlannedConsumption(BaseModel):
    """Projected consumption for a specific month"""
    month: str = Field(..., description="Month in YYYY-MM format")
    baseline_dbu: float = Field(..., description="Historical average DBU")
    planned_dbu: float = Field(..., description="Planned additional DBU from use cases")
    total_dbu: float = Field(..., description="Total projected DBU")
    active_use_cases: List[str] = Field(..., description="Names of active use cases in this month")
    # v1.3: Per-use-case breakdown for individual curves
    use_case_breakdown: Optional[List[UseCaseConsumption]] = Field(None, description="Per-use-case consumption breakdown")
