"""Account configuration persistence with Unity Catalog (v1.4.0)

Stores customer/account -> table_path mappings so users don't need to
re-enter consumption data sources for known accounts.
"""
from typing import List, Optional
from datetime import datetime
import uuid
import requests
from .logger import logger
from .models import AccountConfigIn, AccountConfigOut, AccountConfigSearch
from .config import conf


# Unity Catalog table for account configurations
# Using schema from config for multi-workspace support
def get_accounts_table() -> str:
    return f"{conf.horizon_schema}.horizon_account_configs"


def _execute_sql(sql: str, raise_on_error: bool = True) -> List[List]:
    """Execute SQL using direct REST API (same pattern as usecases.py)
    
    Args:
        sql: SQL statement to execute
        raise_on_error: If True, raise exception on failure. If False, return empty list.
    """
    logger.info(f"[SQL-Accounts] Executing: {sql[:200]}...")
    logger.info(f"[SQL-Accounts] Using schema: {conf.horizon_schema}")
    
    if not conf.databricks_token or not conf.databricks_host or not conf.sql_warehouse_id:
        error_msg = f"Config missing: token={bool(conf.databricks_token)}, host={bool(conf.databricks_host)}, warehouse={bool(conf.sql_warehouse_id)}"
        logger.error(error_msg)
        if raise_on_error:
            raise Exception(error_msg)
        return []

    headers = {
        "Authorization": f"Bearer {conf.databricks_token}",
        "Content-Type": "application/json"
    }
    url = f"{conf.databricks_host}/api/2.0/sql/statements"
    
    payload = {
        "statement": sql,
        "warehouse_id": conf.sql_warehouse_id,
        "disposition": "INLINE",
        "wait_timeout": "30s"
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=40)
        response.raise_for_status()
        
        result = response.json()
        state = result.get("status", {}).get("state")
        logger.info(f"[SQL-Accounts] State: {state}")
        
        if state == "SUCCEEDED":
            row_set = result.get("result", {}).get("data_array", [])
            logger.info(f"[SQL-Accounts] Returned {len(row_set)} rows")
            return row_set
        else:
            error_message = result.get("status", {}).get("error", {}).get("message", "Unknown error")
            logger.error(f"[SQL-Accounts] Failed: {error_message}")
            if raise_on_error:
                raise Exception(f"SQL failed: {error_message}")
            return []
    except requests.exceptions.RequestException as e:
        logger.error(f"[SQL-Accounts] Request failed: {e}")
        if raise_on_error:
            raise Exception(f"SQL request failed: {e}")
        return []
    except Exception as e:
        logger.error(f"[SQL-Accounts] Error: {e}")
        if raise_on_error:
            raise
        return []


def ensure_table_exists() -> bool:
    """Create the account configs table if it doesn't exist"""
    table = get_accounts_table()
    logger.info(f"[ensure_table] Ensuring accounts table: {table}")
    sql = f"""
    CREATE TABLE IF NOT EXISTS {table} (
        id STRING,
        customer_name STRING,
        table_path STRING,
        created_by STRING,
        created_at TIMESTAMP,
        updated_at TIMESTAMP
    )
    """
    try:
        _execute_sql(sql, raise_on_error=False)
        logger.info(f"[ensure_table] Accounts table ready: {table}")
        return True
    except Exception as e:
        logger.error(f"[ensure_table] Failed: {e}")
        return False


def list_accounts(search_query: Optional[str] = None) -> List[AccountConfigSearch]:
    """List all known account configurations (for autocomplete)
    
    Args:
        search_query: Optional partial match on customer_name
    
    Returns:
        List of account configs for autocomplete
    """
    # Ensure table exists
    ensure_table_exists()
    
    where_clause = ""
    if search_query:
        # Case-insensitive partial match
        search_escaped = search_query.replace("'", "''")
        where_clause = f"WHERE LOWER(customer_name) LIKE LOWER('%{search_escaped}%')"
    
    sql = f"""
    SELECT customer_name, table_path, created_by, updated_at
    FROM {get_accounts_table()}
    {where_clause}
    ORDER BY updated_at DESC
    LIMIT 50
    """
    
    try:
        results = _execute_sql(sql, raise_on_error=False)
        accounts = []
        for row in results:
            accounts.append(AccountConfigSearch(
                customer_name=str(row[0]),
                table_path=str(row[1]),
                last_used_by=str(row[2]) if row[2] else None
            ))
        logger.info(f"[list_accounts] Returning {len(accounts)} accounts")
        return accounts
    except Exception as e:
        logger.error(f"[list_accounts] Failed: {e}")
        return []


def get_account_config(customer_name: str) -> Optional[AccountConfigOut]:
    """Get account configuration by customer name (case-insensitive)
    
    Args:
        customer_name: The customer/account name to look up
    
    Returns:
        Account config if found, None otherwise
    """
    customer_escaped = customer_name.replace("'", "''")
    
    sql = f"""
    SELECT id, customer_name, table_path, created_by, created_at, updated_at
    FROM {get_accounts_table()}
    WHERE LOWER(customer_name) = LOWER('{customer_escaped}')
    LIMIT 1
    """
    
    try:
        results = _execute_sql(sql)
        if results and len(results) > 0:
            row = results[0]
            return AccountConfigOut(
                id=str(row[0]),
                customer_name=str(row[1]),
                table_path=str(row[2]),
                created_by=str(row[3]) if row[3] else None,
                created_at=str(row[4]),
                updated_at=str(row[5])
            )
        return None
    except Exception as e:
        logger.error(f"Failed to get account config: {e}")
        return None


def save_account_config(
    config_in: AccountConfigIn,
    user_email: Optional[str] = None
) -> AccountConfigOut:
    """Save or update an account configuration
    
    If the customer_name already exists, update the table_path.
    Otherwise, create a new entry.
    
    Args:
        config_in: Account configuration input
        user_email: Email of user saving this config
    
    Returns:
        The saved account configuration
    """
    # Ensure table exists before any operations
    ensure_table_exists()
    
    now = datetime.utcnow()
    
    # Check if config already exists
    existing = get_account_config(config_in.customer_name)
    
    # Escape values for SQL
    customer_escaped = config_in.customer_name.replace("'", "''")
    table_escaped = config_in.table_path.replace("'", "''")
    user_email_escaped = user_email.replace("'", "''") if user_email else None
    user_email_value = f"'{user_email_escaped}'" if user_email_escaped else "NULL"
    
    if existing:
        # Update existing config
        sql = f"""
        UPDATE {get_accounts_table()}
        SET table_path = '{table_escaped}',
            created_by = {user_email_value},
            updated_at = TIMESTAMP'{now.strftime("%Y-%m-%d %H:%M:%S")}'
        WHERE LOWER(customer_name) = LOWER('{customer_escaped}')
        """
        _execute_sql(sql)
        logger.info(f"Updated account config for: {config_in.customer_name}")
        
        return AccountConfigOut(
            id=existing.id,
            customer_name=config_in.customer_name,
            table_path=config_in.table_path,
            created_by=user_email,
            created_at=existing.created_at,
            updated_at=now.isoformat()
        )
    else:
        # Create new config
        config_id = str(uuid.uuid4())
        
        sql = f"""
        INSERT INTO {get_accounts_table()} VALUES (
            '{config_id}',
            '{customer_escaped}',
            '{table_escaped}',
            {user_email_value},
            TIMESTAMP'{now.strftime("%Y-%m-%d %H:%M:%S")}',
            TIMESTAMP'{now.strftime("%Y-%m-%d %H:%M:%S")}'
        )
        """
        _execute_sql(sql)
        logger.info(f"Created account config for: {config_in.customer_name}")
        
        return AccountConfigOut(
            id=config_id,
            customer_name=config_in.customer_name,
            table_path=config_in.table_path,
            created_by=user_email,
            created_at=now.isoformat(),
            updated_at=now.isoformat()
        )


def delete_account_config(customer_name: str) -> bool:
    """Delete an account configuration
    
    Args:
        customer_name: The customer/account name to delete
    
    Returns:
        True if deleted, False otherwise
    """
    customer_escaped = customer_name.replace("'", "''")
    
    sql = f"""
    DELETE FROM {get_accounts_table()}
    WHERE LOWER(customer_name) = LOWER('{customer_escaped}')
    """
    
    try:
        _execute_sql(sql)
        logger.info(f"Deleted account config for: {customer_name}")
        return True
    except Exception as e:
        logger.error(f"Failed to delete account config: {e}")
        return False



