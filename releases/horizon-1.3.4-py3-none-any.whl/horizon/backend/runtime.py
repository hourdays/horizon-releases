"""DISABLED - No SDK runtime for PAT-only implementation"""
from .config import conf, AppConfig


class Runtime:
    def __init__(self):
        self.config: AppConfig = conf

    @property
    def ws(self):
        # Disabled - use direct REST API calls instead
        raise NotImplementedError("WorkspaceClient disabled for PAT-only implementation")


rt = Runtime()
