app_name = "horizon"
app_module = "horizon.backend.app:app"
app_slug = "horizon"