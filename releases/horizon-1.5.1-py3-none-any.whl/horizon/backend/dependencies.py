"""DISABLED - No OAuth dependencies for PAT-only implementation"""
# This file is kept for compatibility but all OAuth functionality is disabled
