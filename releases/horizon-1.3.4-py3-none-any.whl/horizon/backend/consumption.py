"""Consumption data endpoints (v1.1.0) - Direct SQL API calls with PAT"""
from typing import List, Dict, Any
import requests
import time
from .logger import logger
from .config import conf
from .models import (
    BaselineMetrics,
    MonthlyConsumption,
    WorkspaceConsumption,
)


def _execute_sql_via_rest(sql: str) -> List[List[Any]]:
    """Execute SQL using direct REST API calls (bypasses SDK OAuth conflict)"""
    if not conf.databricks_token or not conf.databricks_host or not conf.sql_warehouse_id:
        raise Exception("Databricks token, host, and warehouse ID must be configured")
    
    # Step 1: Submit statement
    url = f"{conf.databricks_host}/api/2.0/sql/statements"
    headers = {
        "Authorization": f"Bearer {conf.databricks_token}",
        "Content-Type": "application/json"
    }
    payload = {
        "statement": sql,
        "warehouse_id": conf.sql_warehouse_id,
        "wait_timeout": "30s"
    }
    
    logger.info(f"Executing SQL via REST API on warehouse {conf.sql_warehouse_id}")
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=35)
        response.raise_for_status()
        result = response.json()
        
        # Check if we got results
        if result.get("status", {}).get("state") == "SUCCEEDED":
            # Extract data from result
            if "result" in result and "data_array" in result["result"]:
                logger.info(f"SQL execution successful, got {len(result['result']['data_array'])} rows")
                return result["result"]["data_array"]
            else:
                logger.warning("SQL succeeded but no data returned")
                return []
        else:
            logger.error(f"SQL execution failed: {result}")
            return []
            
    except Exception as e:
        logger.error(f"SQL execution via REST failed: {e}")
        return []


def get_baseline_metrics(ws: Any, table_path: str) -> BaselineMetrics:
    """Calculate baseline consumption metrics using direct SQL API (full months only)"""
    try:
        sql = f"""
        WITH monthly_totals AS (
            SELECT 
                yearMonth,
                SUM(dbuDollars) as monthly_total
            FROM {table_path}
            GROUP BY yearMonth
        ),
        current_month_str AS (
            SELECT DATE_FORMAT(CURRENT_DATE(), 'yyyy-MM') as current_month
        ),
        full_months AS (
            SELECT *
            FROM monthly_totals
            WHERE yearMonth < (SELECT current_month FROM current_month_str)
        ),
        recent_full_months AS (
            SELECT *
            FROM full_months
            WHERE yearMonth >= DATE_FORMAT(ADD_MONTHS(CURRENT_DATE(), -13), 'yyyy-MM')
            ORDER BY yearMonth DESC
        ),
        last_full_month AS (
            SELECT yearMonth, monthly_total
            FROM recent_full_months
            LIMIT 1
        ),
        last_3_months AS (
            SELECT SUM(monthly_total) as total_3m
            FROM (
                SELECT monthly_total
                FROM recent_full_months
                LIMIT 3
            )
        ),
        stats AS (
            SELECT 
                AVG(monthly_total) as avg_monthly,
                MIN(yearMonth) as earliest_month
            FROM recent_full_months
        ),
        workspaces AS (
            SELECT COUNT(DISTINCT sfdc_workspace_id) as total_workspaces
            FROM {table_path}
        )
        SELECT 
            COALESCE(lfm.monthly_total, 0) as last_full_month_dbu,
            COALESCE(s.avg_monthly, 0) as average_monthly_dbu,
            COALESCE(l3m.total_3m, 0) as last_3_months_total,
            w.total_workspaces,
            s.earliest_month,
            lfm.yearMonth as latest_full_month
        FROM last_full_month lfm
        CROSS JOIN stats s
        CROSS JOIN workspaces w
        CROSS JOIN last_3_months l3m
        """
        
        results = _execute_sql_via_rest(sql)
        
        if results and len(results) > 0:
            row = results[0]
            return BaselineMetrics(
                last_full_month_dbu=float(row[0] or 0),
                average_monthly_dbu=float(row[1] or 0),
                last_3_months_total=float(row[2] or 0),
                total_workspaces=int(row[3] or 0),
                earliest_month=str(row[4] or "N/A"),
                latest_full_month=str(row[5] or "N/A")
            )
        else:
            logger.warning("No baseline data returned")
            return BaselineMetrics(
                last_full_month_dbu=0.0,
                average_monthly_dbu=0.0,
                last_3_months_total=0.0,
                total_workspaces=0,
                earliest_month="N/A",
                latest_full_month="N/A"
            )
            
    except Exception as e:
        logger.error(f"Failed to get baseline metrics: {e}")
        return BaselineMetrics(
            last_full_month_dbu=0.0,
            average_monthly_dbu=0.0,
            last_3_months_total=0.0,
            total_workspaces=0,
            earliest_month="N/A",
            latest_full_month="N/A"
        )


def get_monthly_history(ws: Any, table_path: str, months: int = 12) -> List[MonthlyConsumption]:
    """Get monthly consumption history using direct SQL API"""
    try:
        sql = f"""
        WITH current_month_str AS (
            SELECT DATE_FORMAT(CURRENT_DATE(), 'yyyy-MM') as current_month
        ),
        monthly_data AS (
            SELECT 
                yearMonth,
                SUM(dbuDollars) as total_dbu,
                COUNT(DISTINCT sfdc_workspace_id) as workspace_count
            FROM {table_path}
            WHERE yearMonth < (SELECT current_month FROM current_month_str)
            GROUP BY yearMonth
            ORDER BY yearMonth DESC
            LIMIT {months}
        )
        SELECT 
            yearMonth,
            total_dbu,
            workspace_count
        FROM monthly_data
        ORDER BY yearMonth ASC
        """
        
        results = _execute_sql_via_rest(sql)
        
        history = []
        for row in results:
            history.append(MonthlyConsumption(
                month=str(row[0]),
                total_dbu=float(row[1] or 0),
                workspace_count=int(row[2] or 0)
            ))
        
        return history
        
    except Exception as e:
        logger.error(f"Failed to get monthly history: {e}")
        return []


def get_workspace_breakdown(ws: Any, table_path: str) -> List[WorkspaceConsumption]:
    """Get per-workspace consumption breakdown using direct SQL API"""
    try:
        sql = f"""
        SELECT 
            workspace_name,
            sfdc_workspace_id,
            SUM(dbuDollars) as total_dbu,
            AVG(dbuDollars) as avg_monthly_dbu,
            COUNT(DISTINCT yearMonth) as months_active
        FROM {table_path}
        GROUP BY workspace_name, sfdc_workspace_id
        ORDER BY total_dbu DESC
        """
        
        results = _execute_sql_via_rest(sql)
        
        breakdown = []
        for row in results:
            breakdown.append(WorkspaceConsumption(
                workspace_name=str(row[0]),
                workspace_id=int(row[1] or 0),
                total_dbu=float(row[2] or 0),
                average_monthly_dbu=float(row[3] or 0),
                months_active=int(row[4] or 0)
            ))
        
        return breakdown
        
    except Exception as e:
        logger.error(f"Failed to get workspace breakdown: {e}")
        return []
