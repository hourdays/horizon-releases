"""Use case planning with Unity Catalog persistence (v1.3.0)"""
from typing import List, Optional
from datetime import datetime
import uuid
import math
import requests
from .logger import logger
from .models import UseCaseIn, UseCaseOut, UseCaseConsumption
from .config import conf


# Unity Catalog table for persistent storage
# Using schema from config for multi-workspace support
def get_use_cases_table() -> str:
    return f"{conf.horizon_schema}.horizon_use_cases"


def _execute_sql(sql: str, raise_on_error: bool = True) -> List[List]:
    """Execute SQL using direct REST API (same pattern as consumption.py)
    
    Args:
        sql: SQL statement to execute
        raise_on_error: If True, raise exception on failure. If False, return empty list.
    """
    logger.info(f"[SQL] Executing: {sql[:200]}...")
    logger.info(f"[SQL] Using schema from config: {conf.horizon_schema}")
    
    if not conf.databricks_token or not conf.databricks_host or not conf.sql_warehouse_id:
        error_msg = f"Databricks configuration missing: token={bool(conf.databricks_token)}, host={bool(conf.databricks_host)}, warehouse={bool(conf.sql_warehouse_id)}"
        logger.error(error_msg)
        if raise_on_error:
            raise Exception(error_msg)
        return []

    headers = {
        "Authorization": f"Bearer {conf.databricks_token}",
        "Content-Type": "application/json"
    }
    url = f"{conf.databricks_host}/api/2.0/sql/statements"
    
    payload = {
        "statement": sql,
        "warehouse_id": conf.sql_warehouse_id,
        "disposition": "INLINE",
        "wait_timeout": "30s"
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=40)
        response.raise_for_status()
        
        result = response.json()
        state = result.get("status", {}).get("state")
        logger.info(f"[SQL] Execution state: {state}")
        
        if state == "SUCCEEDED":
            row_set = result.get("result", {}).get("data_array", [])
            logger.info(f"[SQL] Returned {len(row_set)} rows")
            return row_set
        else:
            error_message = result.get("status", {}).get("error", {}).get("message", "Unknown error")
            logger.error(f"[SQL] Failed with state {state}: {error_message}")
            if raise_on_error:
                raise Exception(f"SQL failed: {error_message}")
            return []
    except requests.exceptions.RequestException as e:
        logger.error(f"[SQL] Request failed: {e}")
        if raise_on_error:
            raise Exception(f"SQL request failed: {e}")
        return []
    except Exception as e:
        logger.error(f"[SQL] Unexpected error: {e}")
        if raise_on_error:
            raise
        return []


def ensure_table_exists() -> bool:
    """Create the use cases table if it doesn't exist"""
    table = get_use_cases_table()
    logger.info(f"[ensure_table] Ensuring table exists: {table}")
    sql = f"""
    CREATE TABLE IF NOT EXISTS {table} (
        id STRING,
        name STRING,
        description STRING,
        live_date STRING,
        onboarding_months INT,
        dbu_at_scale DOUBLE,
        onboarding_pattern STRING,
        category STRING,
        status STRING,
        created_at TIMESTAMP,
        updated_at TIMESTAMP,
        user_email STRING,
        customer_name STRING
    )
    """
    try:
        _execute_sql(sql, raise_on_error=False)
        logger.info(f"[ensure_table] Table ready: {table}")
        return True
    except Exception as e:
        logger.error(f"[ensure_table] Failed: {e}")
        return False


def calculate_pattern_multiplier(pattern: str, progress: float, at_scale: bool = False) -> float:
    """
    Calculate DBU multiplier based on onboarding pattern and progress
    
    Args:
        pattern: linear, hill, exponential, s-curve, front-loaded
        progress: Value between 0 (start) and 1 (go-live)
        at_scale: True if we're past go-live (for patterns like hill that have post-live adjustments)
    
    Returns:
        Multiplier representing % of dbu_at_scale (can exceed 1.0 for some patterns)
    """
    # Hill pattern has special at-scale behavior: -20% optimization
    if pattern in ("hill", "camel"):
        if at_scale or progress >= 1.0:
            return 0.8  # -20% at scale due to optimization
        if progress <= 0.0:
            return 0.0
        # During onboarding: peaks at +30% of dbu_at_scale (1.3x)
        # At go-live: settles to -20% of dbu_at_scale (0.8x)
        # Smooth curve: 0.8*x + 0.9*sin(πx) peaks at ~1.3 around 60% progress
        return 0.8 * progress + 0.9 * math.sin(math.pi * progress)
    
    # Other patterns: 100% at scale
    if progress >= 1.0 or at_scale:
        return 1.0
    if progress <= 0.0:
        return 0.0
    
    if pattern == "linear":
        return progress
    
    elif pattern == "exponential":
        return progress ** 2
    
    elif pattern == "s-curve":
        k = 10
        x_shifted = (progress - 0.5) * k
        return 1 / (1 + math.exp(-x_shifted))
    
    elif pattern == "front-loaded":
        return math.sqrt(progress)
    
    else:
        return progress


def create_use_case(use_case_in: UseCaseIn, user_email: Optional[str] = None) -> UseCaseOut:
    """Create a new use case in UC table
    
    Args:
        use_case_in: Use case input data
        user_email: Email of the user creating this use case (v1.3)
    """
    # Ensure table exists before any operations
    ensure_table_exists()
    
    use_case_id = str(uuid.uuid4())
    now = datetime.utcnow()
    
    # Determine status based on live_date (for now, all new cases are "onboarding")
    status = "onboarding"
    
    # Escape single quotes in strings for SQL
    name_escaped = use_case_in.name.replace("'", "''")
    desc_escaped = use_case_in.description.replace("'", "''") if use_case_in.description else None
    desc_value = f"'{desc_escaped}'" if desc_escaped else "NULL"
    
    # v1.3: Handle new columns (user_email, customer_name)
    user_email_escaped = user_email.replace("'", "''") if user_email else None
    user_email_value = f"'{user_email_escaped}'" if user_email_escaped else "NULL"
    
    customer_escaped = use_case_in.customer_name.replace("'", "''") if use_case_in.customer_name else None
    customer_value = f"'{customer_escaped}'" if customer_escaped else "NULL"
    
    sql = f"""
    INSERT INTO {get_use_cases_table()} VALUES (
        '{use_case_id}',
        '{name_escaped}',
        {desc_value},
        '{use_case_in.live_date}',
        {use_case_in.onboarding_months},
        {use_case_in.dbu_at_scale},
        '{use_case_in.onboarding_pattern}',
        '{use_case_in.category or "other"}',
        '{status}',
        TIMESTAMP'{now.strftime("%Y-%m-%d %H:%M:%S")}',
        TIMESTAMP'{now.strftime("%Y-%m-%d %H:%M:%S")}',
        {user_email_value},
        {customer_value}
    )
    """
    
    _execute_sql(sql)
    logger.info(f"Created use case: {use_case_in.name} (ID: {use_case_id}, user: {user_email})")
    
    return UseCaseOut(
        id=use_case_id,
        name=use_case_in.name,
        description=use_case_in.description,
        live_date=use_case_in.live_date,
        onboarding_months=use_case_in.onboarding_months,
        dbu_at_scale=use_case_in.dbu_at_scale,
        onboarding_pattern=use_case_in.onboarding_pattern,
        category=use_case_in.category or "other",
        status=status,
        created_at=now.isoformat(),
        updated_at=now.isoformat(),
        user_email=user_email,
        customer_name=use_case_in.customer_name
    )


def list_use_cases(
    user_email: Optional[str] = None,
    customer_name: Optional[str] = None
) -> List[UseCaseOut]:
    """List use cases from UC table
    
    Args:
        user_email: Filter by user email (v1.3) - REQUIRED for multi-user
        customer_name: Filter by customer name (v1.3) - REQUIRED for multi-user
    """
    # Ensure table exists before any operations
    ensure_table_exists()
    
    # Build WHERE clause for filtering
    # Both user_email AND customer_name must match for multi-user isolation
    conditions = []
    
    # Treat empty strings as None
    user_email = user_email.strip() if user_email else None
    customer_name = customer_name.strip() if customer_name else None
    
    logger.info(f"list_use_cases filtering: user_email='{user_email}', customer_name='{customer_name}'")
    
    if user_email:
        user_email_escaped = user_email.replace("'", "''")
        conditions.append(f"user_email = '{user_email_escaped}'")
    if customer_name:
        customer_escaped = customer_name.replace("'", "''")
        conditions.append(f"customer_name = '{customer_escaped}'")
    
    # If no filters provided, return empty list (require user context)
    if not conditions:
        logger.warning("list_use_cases called without user_email or customer_name - returning empty list")
        return []
    
    where_clause = f"WHERE {' AND '.join(conditions)}"
    
    sql = f"""
    SELECT id, name, description, live_date, onboarding_months, dbu_at_scale,
           onboarding_pattern, category, status, created_at, updated_at,
           user_email, customer_name
    FROM {get_use_cases_table()}
    {where_clause}
    ORDER BY created_at DESC
    """
    
    logger.info(f"Executing list_use_cases SQL: {sql}")
    results = _execute_sql(sql)
    logger.info(f"list_use_cases SQL returned {len(results)} rows")
    
    use_cases = []
    for row in results:
        logger.info(f"Processing use case row with {len(row)} columns: {row}")
        try:
            use_cases.append(UseCaseOut(
                id=str(row[0]),
                name=str(row[1]),
                description=str(row[2]) if row[2] else None,
                live_date=str(row[3]),
                onboarding_months=int(row[4]),
                dbu_at_scale=float(row[5]),
                onboarding_pattern=str(row[6]),
                category=str(row[7]),
                status=str(row[8]),
                created_at=str(row[9]),
                updated_at=str(row[10]),
                user_email=str(row[11]) if len(row) > 11 and row[11] else None,
                customer_name=str(row[12]) if len(row) > 12 and row[12] else None
            ))
        except Exception as e:
            logger.error(f"Failed to parse use case row: {e}, row data: {row}")
    
    return use_cases


def get_use_case(use_case_id: str) -> Optional[UseCaseOut]:
    """Get a specific use case by ID from UC table"""
    sql = f"""
    SELECT id, name, description, live_date, onboarding_months, dbu_at_scale,
           onboarding_pattern, category, status, created_at, updated_at,
           user_email, customer_name
    FROM {get_use_cases_table()}
    WHERE id = '{use_case_id}'
    """
    
    results = _execute_sql(sql)
    
    if results and len(results) > 0:
        row = results[0]
        return UseCaseOut(
            id=str(row[0]),
            name=str(row[1]),
            description=str(row[2]) if row[2] else None,
            live_date=str(row[3]),
            onboarding_months=int(row[4]),
            dbu_at_scale=float(row[5]),
            onboarding_pattern=str(row[6]),
            category=str(row[7]),
            status=str(row[8]),
            created_at=str(row[9]),
            updated_at=str(row[10]),
            user_email=str(row[11]) if len(row) > 11 and row[11] else None,
            customer_name=str(row[12]) if len(row) > 12 and row[12] else None
        )
    
    return None


def update_use_case(use_case_id: str, use_case_in: UseCaseIn) -> Optional[UseCaseOut]:
    """Update an existing use case in UC table"""
    existing = get_use_case(use_case_id)
    if not existing:
        return None
    
    now = datetime.utcnow()
    
    # Escape single quotes in strings for SQL
    name_escaped = use_case_in.name.replace("'", "''")
    desc_escaped = use_case_in.description.replace("'", "''") if use_case_in.description else None
    desc_value = f"'{desc_escaped}'" if desc_escaped else "NULL"
    
    # v1.3: Handle customer_name update
    customer_escaped = use_case_in.customer_name.replace("'", "''") if use_case_in.customer_name else None
    customer_value = f"'{customer_escaped}'" if customer_escaped else "NULL"
    
    sql = f"""
    UPDATE {get_use_cases_table()}
    SET name = '{name_escaped}',
        description = {desc_value},
        live_date = '{use_case_in.live_date}',
        onboarding_months = {use_case_in.onboarding_months},
        dbu_at_scale = {use_case_in.dbu_at_scale},
        onboarding_pattern = '{use_case_in.onboarding_pattern}',
        category = '{use_case_in.category or "other"}',
        customer_name = {customer_value},
        updated_at = TIMESTAMP'{now.strftime("%Y-%m-%d %H:%M:%S")}'
    WHERE id = '{use_case_id}'
    """
    
    _execute_sql(sql)
    logger.info(f"Updated use case: {use_case_in.name} (ID: {use_case_id})")
    
    return UseCaseOut(
        id=use_case_id,
        name=use_case_in.name,
        description=use_case_in.description,
        live_date=use_case_in.live_date,
        onboarding_months=use_case_in.onboarding_months,
        dbu_at_scale=use_case_in.dbu_at_scale,
        onboarding_pattern=use_case_in.onboarding_pattern,
        category=use_case_in.category or "other",
        status=existing.status,
        created_at=existing.created_at,
        updated_at=now.isoformat(),
        user_email=existing.user_email,
        customer_name=use_case_in.customer_name
    )


def delete_use_case(use_case_id: str) -> bool:
    """Delete a use case from UC table"""
    sql = f"""
    DELETE FROM {get_use_cases_table()}
    WHERE id = '{use_case_id}'
    """
    
    _execute_sql(sql)
    logger.info(f"Deleted use case (ID: {use_case_id})")
    
    return True


def calculate_projected_consumption(
    baseline_monthly_avg: float,
    start_month: str,
    projection_months: int = 12,
    user_email: Optional[str] = None,
    customer_name: Optional[str] = None,
    use_case_ids: Optional[List[str]] = None
) -> List[dict]:
    """
    Calculate projected consumption including baseline + planned use cases from UC table
    
    Args:
        baseline_monthly_avg: Historical average monthly DBU
        start_month: Starting month for projection (YYYY-MM)
        projection_months: Number of months to project
        user_email: Filter use cases by user email (v1.3)
        customer_name: Filter use cases by customer name (v1.3)
        use_case_ids: Optional list of specific use case IDs to include (v1.3)
    
    Returns:
        List of projected monthly consumption with per-use-case breakdown
    """
    from datetime import datetime
    
    # Get use cases from UC (with optional filtering)
    use_cases = list_use_cases(user_email=user_email, customer_name=customer_name)
    
    # Filter to specific use case IDs if provided
    if use_case_ids:
        use_cases = [uc for uc in use_cases if uc.id in use_case_ids]
    
    # Parse start month
    start_year, start_month_num = map(int, start_month.split("-"))
    
    projections = []
    
    for i in range(projection_months):
        # Calculate current month
        current_month_num = start_month_num + i
        current_year = start_year
        
        # Handle year rollover
        while current_month_num > 12:
            current_month_num -= 12
            current_year += 1
        
        month_str = f"{current_year}-{str(current_month_num).zfill(2)}"
        month_date = datetime(current_year, current_month_num, 1)
        
        # Calculate planned DBU for this month
        planned_dbu = 0.0
        active_use_cases = []
        use_case_breakdown = []  # v1.3: Per-use-case breakdown
        
        for use_case in use_cases:
            # Parse live date
            live_year, live_month = map(int, use_case.live_date.split("-"))
            live_date = datetime(live_year, live_month, 1)
            
            # Calculate onboarding start date
            onboarding_start_month_num = live_month - use_case.onboarding_months
            onboarding_start_year = live_year
            while onboarding_start_month_num < 1:
                onboarding_start_month_num += 12
                onboarding_start_year -= 1
            
            onboarding_start_date = datetime(onboarding_start_year, onboarding_start_month_num, 1)
            
            # Check if use case is active in this month
            if month_date >= onboarding_start_date:
                # Determine phase and DBU consumption
                if month_date < live_date:
                    # Onboarding phase - calculate progress and apply pattern
                    months_since_start = (month_date.year - onboarding_start_date.year) * 12 + (month_date.month - onboarding_start_date.month)
                    progress = months_since_start / use_case.onboarding_months
                    multiplier = calculate_pattern_multiplier(use_case.onboarding_pattern, progress)
                    monthly_dbu = use_case.dbu_at_scale * multiplier
                    planned_dbu += monthly_dbu
                    active_use_cases.append(f"{use_case.name} ({int(multiplier*100)}%)")
                    
                    # v1.3: Add to breakdown
                    use_case_breakdown.append(UseCaseConsumption(
                        use_case_id=use_case.id,
                        use_case_name=use_case.name,
                        dbu=monthly_dbu,
                        percentage=multiplier * 100
                    ))
                else:
                    # Production phase (at scale) - apply pattern's at-scale multiplier
                    # For hill pattern: 0.8 (-20% optimization)
                    # For other patterns: 1.0 (full scale)
                    at_scale_multiplier = calculate_pattern_multiplier(use_case.onboarding_pattern, 1.0, at_scale=True)
                    monthly_dbu = use_case.dbu_at_scale * at_scale_multiplier
                    planned_dbu += monthly_dbu
                    active_use_cases.append(f"{use_case.name} (live)")
                    
                    # v1.3: Add to breakdown
                    use_case_breakdown.append(UseCaseConsumption(
                        use_case_id=use_case.id,
                        use_case_name=use_case.name,
                        dbu=monthly_dbu,
                        percentage=at_scale_multiplier * 100
                    ))
        
        projections.append({
            "month": month_str,
            "baseline_dbu": baseline_monthly_avg,
            "planned_dbu": planned_dbu,
            "total_dbu": baseline_monthly_avg + planned_dbu,
            "active_use_cases": active_use_cases,
            "use_case_breakdown": [uc.model_dump() for uc in use_case_breakdown]  # v1.3
        })
    
    return projections
