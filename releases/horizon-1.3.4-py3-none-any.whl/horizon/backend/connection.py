"""DISABLED - Connection validation disabled for PAT-only implementation"""
# This file is kept for compatibility but all SDK functionality is disabled
